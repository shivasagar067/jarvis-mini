package com.example.jarvis;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.text.DateFormat;
import java.util.*;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    Store store; TextToSpeech tts; LinearLayout content; TextView status; EditText command;

    int bg=0xFF101114, fg=0xFFE8EAED, muted=0xFFB8BCC4;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        store=new Store(this); tts=new TextToSpeech(this,this);
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},5);
        buildHome();
    }

    TextView text(String s,float size){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(fg); v.setPadding(12,10,12,10); return v;
    }
    Button btn(String s, View.OnClickListener l){
        Button b=new Button(this); b.setText(s); b.setOnClickListener(l); return b;
    }
    LinearLayout base(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22,25,22,18); root.setBackgroundColor(bg);
        TextView title=text("JARVIS MINI",27); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,65));
        status=text("Your simple daily assistant",15); status.setTextColor(muted); status.setGravity(Gravity.CENTER); root.addView(status,new LinearLayout.LayoutParams(-1,45));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }
    void buildHome(){
        LinearLayout root=base();
        TextView greet=text("Good morning.\nWhat do you want to do?",21); content.addView(greet);
        content.addView(btn("📝  DAILY TASKS",v->showTasks()),new LinearLayout.LayoutParams(-1,65));
        content.addView(btn("⏰  SET REMINDER",v->showReminder()),new LinearLayout.LayoutParams(-1,65));
        content.addView(btn("🍽️  FOOD ROUTINE",v->showFood()),new LinearLayout.LayoutParams(-1,65));
        content.addView(btn("🧠  MEMORY",v->showMemory()),new LinearLayout.LayoutParams(-1,65));
        content.addView(btn("🎙️  VOICE COMMAND",v->listen()),new LinearLayout.LayoutParams(-1,65));
        TextView tip=text("\nExamples:\n“Add task: walk for 20 minutes”\n“Remind me to drink water in 30 minutes”",15); tip.setTextColor(muted); content.addView(tip);
        setContentView(root);
    }

    void header(String title){
        content.removeAllViews();
        Button back=btn("← Back",v->buildHome()); content.addView(back,new LinearLayout.LayoutParams(-1,55));
        TextView h=text(title,24); content.addView(h);
    }

    void showTasks(){
        header("📝 Today's tasks");
        List<String> ts=store.tasks();
        if(ts.isEmpty()) content.addView(text("No tasks yet. Add your first task below.",18));
        for(int i=0;i<ts.size();i++){
            final int idx=i; CheckBox cb=new CheckBox(this); cb.setText(ts.get(i)); cb.setTextColor(fg); cb.setTextSize(17);
            cb.setOnCheckedChangeListener((b,c)->{if(c){store.removeTask(idx); showTasks();}});
            content.addView(cb);
        }
        EditText e=new EditText(this); e.setHint("New task…"); e.setTextColor(fg); e.setHintTextColor(muted);
        content.addView(e,new LinearLayout.LayoutParams(-1,65));
        content.addView(btn("＋ ADD TASK",v->{store.addTask(e.getText().toString());showTasks();}),new LinearLayout.LayoutParams(-1,60));
    }

    void showReminder(){
        header("⏰ Reminder");
        content.addView(text("What should I remind you about?",18));
        EditText what=new EditText(this); what.setHint("e.g. Drink water"); what.setTextColor(fg); what.setHintTextColor(muted); content.addView(what,new LinearLayout.LayoutParams(-1,65));
        content.addView(text("Minutes from now",16));
        EditText mins=new EditText(this); mins.setHint("10"); mins.setInputType(2); mins.setTextColor(fg); mins.setHintTextColor(muted); content.addView(mins,new LinearLayout.LayoutParams(-1,65));
        content.addView(btn("SET REMINDER",v->{
            String s=what.getText().toString().trim(); long n;
            try{n=Long.parseLong(mins.getText().toString());}catch(Exception e){n=10;}
            if(s.isEmpty()){Toast.makeText(this,"Enter a reminder",Toast.LENGTH_SHORT).show();return;}
            ReminderReceiver.schedule(this,s,System.currentTimeMillis()+n*60000L);
            Toast.makeText(this,"Reminder set for "+n+" minute(s)",Toast.LENGTH_SHORT).show();
            speak("Done. I'll remind you about "+s);
        }),new LinearLayout.LayoutParams(-1,65));
    }

    String food(){
        int h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if(h<10)return "Breakfast: oats or eggs + fruit, and water.";
        if(h<13)return "Snack: fruit, curd/yogurt, or a small handful of nuts if hungry.";
        if(h<16)return "Lunch: vegetables + a protein source + a sensible portion of rice or roti.";
        if(h<19)return "Evening: fruit, roasted chana, or yogurt. Drink water.";
        if(h<23)return "Dinner: vegetables + protein + a moderate carb portion. Keep it comfortable.";
        return "Late night: hydrate and, if you are genuinely hungry, choose something light.";
    }
    void showFood(){ header("🍽️ Food routine"); content.addView(text(food(),20)); content.addView(text("\nThese are general suggestions, not medical or individualized nutrition advice.",14)); }

    void showMemory(){
        header("🧠 Memory");
        String m=store.memory(); content.addView(text(m.isEmpty()?"Nothing saved yet.":("Saved memory:\n"+m),18));
        EditText e=new EditText(this); e.setHint("Remember something…"); e.setTextColor(fg); e.setHintTextColor(muted); content.addView(e,new LinearLayout.LayoutParams(-1,65));
        content.addView(btn("SAVE MEMORY",v->{store.remember(e.getText().toString());showMemory();}),new LinearLayout.LayoutParams(-1,60));
    }

    void listen(){
        if(!SpeechRecognizer.isRecognitionAvailable(this)){Toast.makeText(this,"Speech recognition unavailable",Toast.LENGTH_LONG).show();return;}
        final SpeechRecognizer sr=SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener(){
            public void onResults(Bundle b){ArrayList<String>a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()) command(a.get(0)); sr.destroy();}
            public void onError(int e){sr.destroy();Toast.makeText(MainActivity.this,"I couldn't hear that.",Toast.LENGTH_SHORT).show();}
            public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float v){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){} public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle b){}
        });
        sr.startListening(new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM));
    }

    void command(String s){
        String l=s.toLowerCase(Locale.getDefault()); String ans;
        if(l.startsWith("add task")){
            String t=s.contains(":")?s.substring(s.indexOf(":")+1).trim():s.replaceFirst("(?i)add task","").trim();
            if(t.isEmpty()) ans="Tell me the task."; else {store.addTask(t);ans="Added task: "+t;}
        } else if(l.contains("food")||l.contains("meal")||l.contains("eat")) ans=food();
        else if(l.contains("tasks")||l.contains("my day")) ans=store.tasks().isEmpty()?"You have no tasks.":String.join(", ",store.tasks());
        else if(l.startsWith("remember ")){store.remember(s.substring(9).trim());ans="Remembered."; }
        else if(l.contains("remember")) ans=store.memory().isEmpty()?"I don't have a saved memory yet.":store.memory();
        else if(l.contains("time")) ans="It is "+DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date())+".";
        else ans="Try: Add task: walk, Food routine, or open the reminder screen.";
        status.setText(ans); speak(ans);
    }
    void speak(String s){if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis");}
    @Override public void onInit(int st){if(st==TextToSpeech.SUCCESS)tts.setLanguage(Locale.getDefault());}
    @Override protected void onDestroy(){if(tts!=null)tts.shutdown();super.onDestroy();}
}
