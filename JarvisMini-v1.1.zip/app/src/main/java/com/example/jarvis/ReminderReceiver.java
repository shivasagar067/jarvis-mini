package com.example.jarvis;
import android.app.*;
import android.content.*;
import android.os.Build;
public class ReminderReceiver extends BroadcastReceiver {
    public void onReceive(Context c, Intent i){
        String text=i.getStringExtra("text"); if(text==null)text="Reminder";
        String channel="jarvis_reminders";
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(channel,"Jarvis reminders",NotificationManager.IMPORTANCE_HIGH));
        Notification n=new Notification.Builder(c,channel).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Jarvis reminder").setContentText(text).setAutoCancel(true).build();
        nm.notify((int)(System.currentTimeMillis()%100000),n);
    }
    public static void schedule(Context c,String text,long when){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent in=new Intent(c,ReminderReceiver.class).putExtra("text",text);
        PendingIntent pi=PendingIntent.getBroadcast(c,Math.abs(text.hashCode()),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
    }
}
