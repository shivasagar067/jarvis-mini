package com.example.jarvis;
import android.content.Context;
import java.util.*;
public class Store {
    private final android.content.SharedPreferences p;
    Store(Context c){ p=c.getSharedPreferences("jarvis", Context.MODE_PRIVATE); }
    List<String> tasks(){
        String raw=p.getString("tasks","");
        if(raw.isEmpty()) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(raw.split("\\n",-1)));
    }
    void addTask(String s){
        if(s.trim().isEmpty()) return;
        List<String> a=tasks(); a.add(s.trim()); save(a);
    }
    void removeTask(int i){ List<String>a=tasks(); if(i>=0&&i<a.size()){a.remove(i);save(a);} }
    private void save(List<String>a){p.edit().putString("tasks",String.join("\n",a)).apply();}
    void remember(String s){p.edit().putString("memory",s).apply();}
    String memory(){return p.getString("memory","");}
}
