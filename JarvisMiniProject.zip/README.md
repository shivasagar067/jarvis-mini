# Jarvis Mini
A deliberately small first test build: daily tasks, reminders, food-routine suggestions, voice input/output, and local memory.

No payments, banking access, accessibility automation, cloud API keys, or unnecessary permissions are included.
