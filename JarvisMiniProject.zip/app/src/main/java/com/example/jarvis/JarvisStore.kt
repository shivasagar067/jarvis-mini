package com.example.jarvis
import android.content.Context
class JarvisStore(context: Context) {
    private val p = context.getSharedPreferences("jarvis_mini", Context.MODE_PRIVATE)
    fun tasks(): List<String> = p.getStringSet("tasks", emptySet())?.toList()?.sorted() ?: emptyList()
    fun addTask(text: String) {
        val s = p.getStringSet("tasks", emptySet())!!.toMutableSet()
        s.add(text); p.edit().putStringSet("tasks", s).apply()
    }
    fun remember(text: String) { p.edit().putString("memory", text).apply() }
    fun memory(): String = p.getString("memory", "") ?: ""
}
