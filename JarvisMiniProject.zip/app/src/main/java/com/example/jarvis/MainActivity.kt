package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.text.DateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var store: JarvisStore
    private lateinit var tts: TextToSpeech
    private lateinit var output: TextView
    private lateinit var taskInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = JarvisStore(this)
        tts = TextToSpeech(this, this)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 35, 24, 20)
            setBackgroundColor(0xFF101114.toInt())
        }
        val title = TextView(this).apply {
            text = "JARVIS MINI"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(0xFFE8EAED.toInt())
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 70))

        output = TextView(this).apply {
            textSize = 17f
            setTextColor(0xFFDADCE0.toInt())
            setPadding(8, 10, 8, 10)
            text = "Ready.\n\nTry:\n• What's my day?\n• Food routine\n• Remind me in 10 minutes\n• Add task: drink water"
        }
        root.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))

        taskInput = EditText(this).apply {
            hint = "Task or command…"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA0A6.toInt())
        }
        root.addView(taskInput, LinearLayout.LayoutParams(-1, 100))

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun button(label: String, action: () -> Unit): Button =
            Button(this).apply { text = label; setOnClickListener { action() } }

        row.addView(button("ASK") { process(taskInput.text.toString()) }, LinearLayout.LayoutParams(0, 65, 1f))
        row.addView(button("🎙") { listen() }, LinearLayout.LayoutParams(0, 65, 1f))
        row.addView(button("FOOD") { showFood() }, LinearLayout.LayoutParams(0, 65, 1f))
        root.addView(row)

        root.addView(button("TODAY'S TASKS") { showTasks() }, LinearLayout.LayoutParams(-1, 65))
        setContentView(root)
    }

    private fun process(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        val l = text.lowercase(Locale.getDefault())
        val answer = when {
            l.contains("food") || l.contains("eat") || l.contains("meal") -> foodRoutine()
            l.contains("what's my day") || l.contains("what is my day") || l.contains("tasks") -> tasksText()
            l.startsWith("add task:") -> {
                val task = text.substringAfter(":").trim()
                store.addTask(task)
                "Added: $task"
            }
            l.startsWith("remember ") -> {
                val m = text.substringAfter("remember ").trim()
                store.remember(m); "Remembered."
            }
            l.contains("what do you remember") -> {
                val m = store.memory()
                if (m.isBlank()) "I don't have a saved memory yet." else "You asked me to remember: $m"
            }
            l.startsWith("remind me") -> scheduleNaturalReminder(text)
            l.contains("time") -> "It is ${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())}."
            else -> "I can manage tasks, reminders, food routine suggestions and simple memory. Try 'Food routine' or 'Add task: walk for 20 minutes'."
        }
        output.text = "You: $text\n\nJarvis: $answer"
        tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        taskInput.text.clear()
    }

    private fun scheduleNaturalReminder(text: String): String {
        val m = Regex("""in\s+(\d+)\s+(minute|minutes|hour|hours)""", RegexOption.IGNORE_CASE).find(text)
            ?: return "Try: remind me to drink water in 30 minutes."
        val n = m.groupValues[1].toLong()
        val unit = m.groupValues[2].lowercase()
        val delay = if (unit.startsWith("hour")) n * 3600000L else n * 60000L
        val before = text.substringBefore(" in ", missingDelimiterValue = text)
        val task = before.replace(Regex("(?i)^remind me(?: to)?"), "").trim().ifBlank { "Reminder" }
        val at = System.currentTimeMillis() + delay
        ReminderReceiver.schedule(this, task, at)
        return "Done. I'll remind you about '$task' in $n $unit."
    }

    private fun tasksText(): String {
        val tasks = store.tasks()
        return if (tasks.isEmpty()) "You have no tasks yet." else tasks.joinToString("\n") { "• $it" }
    }

    private fun foodRoutine(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (h) {
            in 5..9 -> "Breakfast: oats or eggs + fruit, and water. Keep added sugar low."
            in 10..12 -> "Mid-morning: fruit, curd/yogurt, or a small handful of nuts if hungry."
            in 13..15 -> "Lunch: vegetables + a protein source + a sensible portion of rice/roti. Drink water."
            in 16..18 -> "Evening: fruit, roasted chana, or yogurt. Avoid turning snacks into a full meal."
            in 19..22 -> "Dinner: keep it balanced and lighter if that suits you—vegetables + protein + a moderate carb portion."
            else -> "Late night: if you're genuinely hungry, choose something light and hydrate; otherwise prioritize sleep."
        }
    }

    private fun showFood() {
        val a = foodRoutine()
        output.text = "🍽️ Today's food suggestion\n\n$a"
        tts.speak(a, TextToSpeech.QUEUE_FLUSH, null, "food")
    }

    private fun showTasks() {
        output.text = "📝 Today's tasks\n\n${tasksText()}"
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition is unavailable.", Toast.LENGTH_LONG).show(); return
        }
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let {
                    taskInput.setText(it); process(it)
                }
                sr.destroy()
            }
            override fun onError(e: Int) { sr.destroy() }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        })
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }
    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
