package com.example.jarvis
import android.app.*
import android.content.*
import android.os.Build
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val text = i.getStringExtra("text") ?: "Reminder"
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = "jarvis_reminders"
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(channel, "Jarvis reminders", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(text.hashCode(), Notification.Builder(c, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Jarvis reminder")
            .setContentText(text).setAutoCancel(true).build())
    }
    companion object {
        fun schedule(c: Context, text: String, at: Long) {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(c, text.hashCode(), Intent(c, ReminderReceiver::class.java).putExtra("text", text),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}
